import java.util.List;

public class Task {

    public static void main(String[] args) {
        //imprimir todos nombres que contengan la letra a y m
        List<String> words = List.of("mateo", "maria", "pepe", "sofia", "clara");
        // filtrar los numeros pares
        //Despues ordenarlos de menor a mayor.
        // despues cada numero multiplicarlo por dos
        //Nota: usar filter, map, sorted.
        List<Integer> numers = List.of(6, 5, 7, 8, 9,10);
    }
}
