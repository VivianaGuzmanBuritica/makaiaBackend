package com.example.integradorSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntegradorSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(IntegradorSpringApplication.class, args);
	}

}
