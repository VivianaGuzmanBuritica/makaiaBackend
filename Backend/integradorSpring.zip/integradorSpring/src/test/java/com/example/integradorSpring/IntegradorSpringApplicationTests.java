package com.example.integradorSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntegradorSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
